<?php
$module_name = 'Expan_Solicitud';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => true,
      'tabDefs' => 
      array (
        'LBL_CONTACT_INFORMATION' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL3' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_contact_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'first_name',
            'customCode' => '{html_options name="salutation" id="salutation" options=$fields.salutation.options selected=$fields.salutation.value}&nbsp;<input name="first_name"  id="first_name" size="25" maxlength="25" type="text" value="{$fields.first_name.value}">',
          ),
          1 => 'phone_work',
        ),
        1 => 
        array (
          0 => 'last_name',
          1 => 'phone_mobile',
        ),
        2 => 
        array (
          0 => 'email1',
        ),
        3 => 
        array (
          0 => 'assigned_user_name',
          1 => 'do_not_call',
        ),
        4 => 
        array (
          0 => 'description',
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'primary_address_street',
            'hideLabel' => true,
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'primary',
              'rows' => 2,
              'cols' => 30,
              'maxlength' => 150,
            ),
          ),
          1 => 
          array (
            'name' => 'alt_address_street',
            'hideLabel' => true,
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'alt',
              'copy' => 'primary',
              'rows' => 2,
              'cols' => 30,
              'maxlength' => 150,
            ),
          ),
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'perfil_franquicia',
            'studio' => 'visible',
            'label' => 'LBL_PERFIL_FRANQUICIA',
          ),
          1 => 
          array (
            'name' => 'situacion_profesional',
            'studio' => 'visible',
            'label' => 'LBL_SITUACION_PROFESIONAL',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'perfil_profesional',
            'label' => 'LBL_PERFIL_PROFESIONAL',
          ),
          1 => 
          array (
            'name' => 'cuando_empezar',
            'studio' => 'visible',
            'label' => 'LBL_CUANDO_EMPEZAR',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'negocio_antes',
            'label' => 'LBL_NEGOCIO_ANTES',
          ),
          1 => 
          array (
            'name' => 'negocio',
            'label' => 'LBL_NEGOCIO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'capital',
            'studio' => 'visible',
            'label' => 'LBL_CAPITAL',
          ),
          1 => 
          array (
            'name' => 'capital_observaciones',
            'label' => 'LBL_CAPITAL_OBSERVACIONES',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'franquicia_principal',
            'studio' => 'visible',
            'label' => 'LBL_FRANQUICIA_PRINCIPAL',
          ),
          1 => 
          array (
            'name' => 'franquicias_secundarias',
            'studio' => 'visible',
            'label' => 'LBL_FRANQUICIAS_SECUNDARIAS',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'otras_franquicias',
            'label' => 'LBL_OTRAS_FRANQUICIAS',
          ),
          1 => 
          array (
            'name' => 'sectores_de_interes',
            'studio' => 'visible',
            'label' => 'LBL_SECTORES_DE_INTERES',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'observaciones_solicitud',
            'label' => 'LBL_OBSERVACIONES_SOLICITUD',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'dispone_local',
            'label' => 'LBL_DISPONE_LOCAL',
          ),
          1 => 
          array (
            'name' => 'negocio_anterior_local',
            'label' => 'LBL_NEGOCIO_ANTERIOR_LOCAL',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'direccion_local',
            'label' => 'LBL_DIRECCION_LOCAL',
          ),
          1 => 
          array (
            'name' => 'superficie_local',
            'label' => 'LBL_SUPERFICIE_LOCAL',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'descripcion_local',
            'label' => 'LBL_DESCRIPCION_LOCAL',
          ),
        ),
      ),
      'lbl_editview_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'estado_sol',
            'studio' => 'visible',
            'label' => 'LBL_ESTADO_SOL',
          ),
          1 => 
          array (
            'name' => 'motivo',
            'label' => 'LBL_MOTIVO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'candidatura_caliente',
            'label' => 'LBL_CANDIDATURA_CALIENTE',
          ),
          1 => 
          array (
            'name' => 'zona',
            'studio' => 'visible',
            'label' => 'LBL_ZONA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'rating',
            'studio' => 'visible',
            'label' => 'LBL_RATING',
          ),
          1 => 
          array (
            'name' => 'perfil_plurifranquiciado',
            'studio' => 'visible',
            'label' => 'LBL_PERFIL_PLURIFRANQUICIADO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'observaciones_candidato',
            'studio' => 'visible',
            'label' => 'LBL_OBSERVACIONES_CANDIDATO',
          ),
        ),
      ),
    ),
  ),
);
?>
