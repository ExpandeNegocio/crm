<?php
$module_name = 'Expan_Solicitud';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => true,
      'tabDefs' => 
      array (
        'LBL_CONTACT_INFORMATION' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL3' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_contact_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'first_name',
            'comment' => 'First name of the contact',
            'label' => 'LBL_FIRST_NAME',
          ),
          1 => 'phone_work',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'last_name',
            'comment' => 'Last name of the contact',
            'label' => 'LBL_LAST_NAME',
          ),
          1 => 'phone_mobile',
        ),
        2 => 
        array (
          0 => 'email1',
          1 => 
          array (
            'name' => 'empresa',
            'label' => 'LBL_EMPRESA',
          ),
        ),
        3 => 
        array (
          0 => 'assigned_user_name',
          1 => 'do_not_call',
        ),
        4 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'fecha_primer_contacto',
            'label' => 'LBL_FECHA_PRIMER_CONTACTO',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'provincia_apertura_1',
            'studio' => 'visible',
            'label' => 'LBL_PROVINCIA_APERTURA_1',
          ),
          1 => 
          array (
            'name' => 'localidad_apertura_1',
            'label' => 'LBL_LOCALIDAD_APERTURA_1',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'provincia_apertura_2',
            'studio' => 'visible',
            'label' => 'LBL_PROVINCIA_APERTURA_2',
          ),
          1 => 
          array (
            'name' => 'localidad_apertura_2',
            'label' => 'LBL_LOCALIDAD_APERTURA_2',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'provincia_apertura_3',
            'studio' => 'visible',
            'label' => 'LBL_PROVINCIA_APERTURA_3',
          ),
          1 => 
          array (
            'name' => 'localidad_apertura_3',
            'label' => 'LBL_LOCALIDAD_APERTURA_3',
          ),
        ),
        8 => 
        array (
          0 => 'primary_address_street',
          1 => 'alt_address_street',
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'perfil_franquicia',
            'studio' => 'visible',
            'label' => 'LBL_PERFIL_FRANQUICIA',
          ),
          1 => 
          array (
            'name' => 'situacion_profesional',
            'studio' => 'visible',
            'label' => 'LBL_SITUACION_PROFESIONAL',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'perfil_profesional',
            'label' => 'LBL_PERFIL_PROFESIONAL',
          ),
          1 => 
          array (
            'name' => 'cuando_empezar',
            'studio' => 'visible',
            'label' => 'LBL_CUANDO_EMPEZAR',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'negocio_antes',
            'label' => 'LBL_NEGOCIO_ANTES',
          ),
          1 => 
          array (
            'name' => 'negocio',
            'label' => 'LBL_NEGOCIO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'capital',
            'studio' => 'visible',
            'label' => 'LBL_CAPITAL',
          ),
          1 => 
          array (
            'name' => 'capital_observaciones',
            'label' => 'LBL_CAPITAL_OBSERVACIONES',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'franquicia_principal',
            'studio' => 'visible',
            'label' => 'LBL_FRANQUICIA_PRINCIPAL',
          ),
          1 => 
          array (
            'name' => 'franquicias_secundarias',
            'studio' => 'visible',
            'label' => 'LBL_FRANQUICIAS_SECUNDARIAS',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'otras_franquicias',
            'label' => 'LBL_OTRAS_FRANQUICIAS',
          ),
          1 => 
          array (
            'name' => 'sectores_de_interes',
            'studio' => 'visible',
            'label' => 'LBL_SECTORES_DE_INTERES',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'observaciones_solicitud',
            'label' => 'LBL_OBSERVACIONES_SOLICITUD',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'dispone_local',
            'label' => 'LBL_DISPONE_LOCAL',
          ),
          1 => 
          array (
            'name' => 'negocio_anterior_local',
            'label' => 'LBL_NEGOCIO_ANTERIOR_LOCAL',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'direccion_local',
            'label' => 'LBL_DIRECCION_LOCAL',
          ),
          1 => 
          array (
            'name' => 'superficie_local',
            'label' => 'LBL_SUPERFICIE_LOCAL',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'descripcion_local',
            'label' => 'LBL_DESCRIPCION_LOCAL',
          ),
        ),
      ),
      'lbl_editview_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'estado_sol',
            'studio' => 'visible',
            'label' => 'LBL_ESTADO_SOL',
          ),
          1 => 
          array (
            'name' => 'motivo',
            'label' => 'LBL_MOTIVO',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'candidatura_caliente',
            'label' => 'LBL_CANDIDATURA_CALIENTE',
          ),
          1 => 
          array (
            'name' => 'zona',
            'studio' => 'visible',
            'label' => 'LBL_ZONA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'rating',
            'studio' => 'visible',
            'label' => 'LBL_RATING',
          ),
          1 => 
          array (
            'name' => 'perfil_plurifranquiciado',
            'studio' => 'visible',
            'label' => 'LBL_PERFIL_PLURIFRANQUICIADO',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'tipo_origen',
            'studio' => 'visible',
            'label' => 'LBL_TIPO_ORIGEN',
          ),
          1 => 
          array (
            'name' => 'actuacion_inmediata',
            'studio' => 'visible',
            'label' => 'LBL_ACTUACION_INMEDIATA',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'observaciones_candidato',
            'studio' => 'visible',
            'label' => 'LBL_OBSERVACIONES_CANDIDATO',
          ),
        ),
      ),
    ),
  ),
);
?>
