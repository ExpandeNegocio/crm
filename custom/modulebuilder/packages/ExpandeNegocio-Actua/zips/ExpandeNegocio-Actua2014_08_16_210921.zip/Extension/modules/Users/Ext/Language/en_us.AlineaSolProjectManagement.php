<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_ASOL_PROJECT_USERS_FROM_ASOL_PROJECT_TITLE'] = 'AsolProject : Participants';
$mod_strings['LBL_ASOL_PROJECT_USERS_1_FROM_ASOL_PROJECT_TITLE'] = 'AsolProject : Editors';
