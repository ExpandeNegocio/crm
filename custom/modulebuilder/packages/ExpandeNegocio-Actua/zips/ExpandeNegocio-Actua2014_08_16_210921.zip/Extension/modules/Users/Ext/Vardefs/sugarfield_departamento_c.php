<?php
 // created: 2014-05-30 18:34:34
$dictionary['User']['fields']['departamento_c']['labelValue']='departamento';

 ?>