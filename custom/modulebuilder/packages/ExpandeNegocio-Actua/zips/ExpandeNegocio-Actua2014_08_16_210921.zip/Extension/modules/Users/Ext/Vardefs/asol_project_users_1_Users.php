<?php
// created: 2014-03-12 14:07:43
$dictionary["User"]["fields"]["asol_project_users_1"] = array (
  'name' => 'asol_project_users_1',
  'type' => 'link',
  'relationship' => 'asol_project_users_1',
  'source' => 'non-db',
  'module' => 'asol_Project',
  'bean_name' => 'asol_Project',
  'vname' => 'LBL_ASOL_PROJECT_USERS_1_FROM_ASOL_PROJECT_TITLE',
);
