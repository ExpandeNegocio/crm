<?php
// created: 2014-08-01 19:44:14
$dictionary["Expan_GestionSolicitudes"]["fields"]["expan_gestionsolicitudes_tasks_1"] = array (
  'name' => 'expan_gestionsolicitudes_tasks_1',
  'type' => 'link',
  'relationship' => 'expan_gestionsolicitudes_tasks_1',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_GESTIONSOLICITUDES_TASKS_1_FROM_TASKS_TITLE',
);
