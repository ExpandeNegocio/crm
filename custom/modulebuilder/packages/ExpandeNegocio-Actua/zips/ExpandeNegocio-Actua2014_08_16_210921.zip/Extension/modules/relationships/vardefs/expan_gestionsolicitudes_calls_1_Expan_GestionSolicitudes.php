<?php
// created: 2014-08-01 19:02:05
$dictionary["Expan_GestionSolicitudes"]["fields"]["expan_gestionsolicitudes_calls_1"] = array (
  'name' => 'expan_gestionsolicitudes_calls_1',
  'type' => 'link',
  'relationship' => 'expan_gestionsolicitudes_calls_1',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_GESTIONSOLICITUDES_CALLS_1_FROM_CALLS_TITLE',
);
