<?php
// created: 2014-02-26 13:28:27
$dictionary["Call"]["fields"]["asol_project_activities_calls"] = array (
  'name' => 'asol_project_activities_calls',
  'type' => 'link',
  'relationship' => 'asol_project_activities_calls',
  'source' => 'non-db',
  'module' => 'asol_Project',
  'bean_name' => false,
  'vname' => 'LBL_ASOL_PROJECT_ACTIVITIES_CALLS_FROM_ASOL_PROJECT_TITLE',
);
