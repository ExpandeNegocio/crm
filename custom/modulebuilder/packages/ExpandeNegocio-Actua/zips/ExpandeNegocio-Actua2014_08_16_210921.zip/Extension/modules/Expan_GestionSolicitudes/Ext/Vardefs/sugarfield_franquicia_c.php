<?php
 // created: 2014-08-11 20:42:47
$dictionary['Expan_GestionSolicitudes']['fields']['franquicia_c']['labelValue']='franquicia';

 ?>