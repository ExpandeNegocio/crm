<?php
// created: 2014-02-26 13:28:28
$dictionary["User"]["fields"]["asol_project_users"] = array (
  'name' => 'asol_project_users',
  'type' => 'link',
  'relationship' => 'asol_project_users',
  'source' => 'non-db',
  'module' => 'asol_Project',
  'bean_name' => false,
  'vname' => 'LBL_ASOL_PROJECT_USERS_FROM_ASOL_PROJECT_TITLE',
);
