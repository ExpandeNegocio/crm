<?php
 // created: 2014-08-01 18:54:09
$layout_defs["Expan_Solicitud"]["subpanel_setup"]['expan_solicitud_expan_gestionsolicitudes_1'] = array (
  'order' => 100,
  'module' => 'Expan_GestionSolicitudes',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_EXPAN_SOLICITUD_EXPAN_GESTIONSOLICITUDES_1_FROM_EXPAN_GESTIONSOLICITUDES_TITLE',
  'get_subpanel_data' => 'expan_solicitud_expan_gestionsolicitudes_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
