<?php
// created: 2014-02-26 13:28:29
$dictionary["Task"]["fields"]["asol_projecttask_activities_tasks"] = array (
  'name' => 'asol_projecttask_activities_tasks',
  'type' => 'link',
  'relationship' => 'asol_projecttask_activities_tasks',
  'source' => 'non-db',
  'module' => 'asol_ProjectTask',
  'bean_name' => false,
  'vname' => 'LBL_ASOL_PROJECTTASK_ACTIVITIES_TASKS_FROM_ASOL_PROJECTTASK_TITLE',
);
