<?php
 // created: 2014-06-21 13:41:22
$dictionary['ProjectTask']['fields']['observaciones_c']['labelValue']='Observaciones';

 ?>