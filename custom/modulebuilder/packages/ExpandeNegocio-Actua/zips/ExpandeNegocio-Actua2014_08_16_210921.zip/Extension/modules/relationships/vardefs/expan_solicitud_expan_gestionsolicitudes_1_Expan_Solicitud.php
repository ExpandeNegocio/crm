<?php
// created: 2014-08-01 18:54:09
$dictionary["Expan_Solicitud"]["fields"]["expan_solicitud_expan_gestionsolicitudes_1"] = array (
  'name' => 'expan_solicitud_expan_gestionsolicitudes_1',
  'type' => 'link',
  'relationship' => 'expan_solicitud_expan_gestionsolicitudes_1',
  'source' => 'non-db',
  'module' => 'Expan_GestionSolicitudes',
  'bean_name' => 'Expan_GestionSolicitudes',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_SOLICITUD_EXPAN_GESTIONSOLICITUDES_1_FROM_EXPAN_GESTIONSOLICITUDES_TITLE',
);
