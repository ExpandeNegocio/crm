<?php
$popupMeta = 
array (
  'moduleMain' => 'Tasks',
  'varName' => 'Task',
  'orderBy' => 'tasks.name',
  'whereClauses' => 
  array (
    'name' => 'tasks.name',
  ),
  'searchInputs' => 
  array (
    0 => 'tasks_number',
    1 => 'name',
    2 => 'priority',
    3 => 'status',
  ),
);
?>
