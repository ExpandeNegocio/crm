<?php 
 // created: 2014-08-16 21:09:16
$mod_strings['LBL_DEPARTAMENTO'] = 'departamento';

?>
