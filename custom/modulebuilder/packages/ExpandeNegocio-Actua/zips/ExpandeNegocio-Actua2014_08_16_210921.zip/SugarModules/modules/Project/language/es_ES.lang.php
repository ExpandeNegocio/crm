<?php 
 // created: 2014-08-16 21:09:14
$mod_strings['LBL_PROJECT_TASKS_SUBPANEL_TITLE'] = 'Tareas de Proyecto';

?>
