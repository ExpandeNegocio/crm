<?php
$module_name = 'Expan_GestionSolicitudes';
$listViewDefs [$module_name] = 
array (
  'EXPAN_SOLICITUD_EXPAN_GESTIONSOLICITUDES_1_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_EXPAN_SOLICITUD_EXPAN_GESTIONSOLICITUDES_1_FROM_EXPAN_SOLICITUD_TITLE',
    'width' => '10%',
    'default' => true,
    'id' => 'EXPAN_SOLICITUD_EXPAN_GESTIONSOLICITUDES_1EXPAN_SOLICITUD_IDA',
  ),
  'FRANQUICIA' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_FRANQUICIA',
    'width' => '10%',
    'default' => true,
  ),
  'ESTADO_SOL' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'default' => true,
    'label' => 'Estado',
    'width' => '10%',
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
);
?>
