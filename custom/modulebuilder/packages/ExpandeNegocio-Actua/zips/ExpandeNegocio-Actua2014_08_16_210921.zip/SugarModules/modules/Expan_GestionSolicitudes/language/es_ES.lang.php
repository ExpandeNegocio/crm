<?php 
 // created: 2014-08-16 21:09:09
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Nuevo Panel 1';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Nuevo Panel 2';
$mod_strings['LBL_CANDIDATURA_CALIENTE'] = 'Candidatura Caliente';
$mod_strings['LBL_CHK_ENTREVISTA'] = 'Entrevista';
$mod_strings['LBL_CHK_ENVIO_CONTRATO'] = 'Envio Contrato';
$mod_strings['LBL_CHK_ENVIO_DOCUMENTACION'] = 'Envio Documentación';
$mod_strings['LBL_CHK_ENVIO_PRECONTRATO'] = 'Envío Precontrato';
$mod_strings['LBL_CHK_RECEPCIO_CUESTIONARIO'] = 'Recepción cuestionario';
$mod_strings['LBL_CHK_INFORMACION_ADICIONAL'] = 'Informacion adicional';
$mod_strings['ENVIO DE DOCUMENTACIóN'] = 'Fecha de envio de Documentación';
$mod_strings['LBL_FRANQUICIA'] = 'franquicia';

?>
