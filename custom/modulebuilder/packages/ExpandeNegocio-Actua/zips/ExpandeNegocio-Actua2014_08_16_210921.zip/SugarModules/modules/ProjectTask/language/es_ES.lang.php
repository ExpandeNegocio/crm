<?php 
 // created: 2014-08-16 21:09:15
$mod_strings['LBL_OBSERVACIONES'] = 'Observaciones';

?>
