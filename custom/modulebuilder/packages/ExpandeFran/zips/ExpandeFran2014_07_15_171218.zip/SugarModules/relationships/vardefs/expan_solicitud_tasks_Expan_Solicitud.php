<?php
// created: 2014-07-15 17:12:16
$dictionary["Expan_Solicitud"]["fields"]["expan_solicitud_tasks"] = array (
  'name' => 'expan_solicitud_tasks',
  'type' => 'link',
  'relationship' => 'expan_solicitud_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_SOLICITUD_TASKS_FROM_TASKS_TITLE',
);
