<?php
// created: 2014-07-31 19:38:11
$dictionary["Expan_Solicitud"]["fields"]["expan_solicitud_users"] = array (
  'name' => 'expan_solicitud_users',
  'type' => 'link',
  'relationship' => 'expan_solicitud_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_SOLICITUD_USERS_FROM_USERS_TITLE',
);
