<?php
// created: 2014-07-12 09:52:47
$dictionary["Expan_Franquicia"]["fields"]["expan_franquicia_expan_documentacion"] = array (
  'name' => 'expan_franquicia_expan_documentacion',
  'type' => 'link',
  'relationship' => 'expan_franquicia_expan_documentacion',
  'source' => 'non-db',
  'module' => 'Expan_Documentacion',
  'bean_name' => 'Expan_Documentacion',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_FRANQUICIA_EXPAN_DOCUMENTACION_FROM_EXPAN_DOCUMENTACION_TITLE',
);
