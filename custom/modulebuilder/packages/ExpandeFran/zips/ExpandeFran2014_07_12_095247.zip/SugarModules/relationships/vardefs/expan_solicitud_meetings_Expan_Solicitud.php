<?php
// created: 2014-07-12 09:52:45
$dictionary["Expan_Solicitud"]["fields"]["expan_solicitud_meetings"] = array (
  'name' => 'expan_solicitud_meetings',
  'type' => 'link',
  'relationship' => 'expan_solicitud_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_SOLICITUD_MEETINGS_FROM_MEETINGS_TITLE',
);
