<?php
// created: 2014-07-12 09:52:45
$dictionary["Expan_Solicitud"]["fields"]["expan_solicitud_expan_franquicia"] = array (
  'name' => 'expan_solicitud_expan_franquicia',
  'type' => 'link',
  'relationship' => 'expan_solicitud_expan_franquicia',
  'source' => 'non-db',
  'module' => 'Expan_Franquicia',
  'bean_name' => 'Expan_Franquicia',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_SOLICITUD_EXPAN_FRANQUICIA_FROM_EXPAN_FRANQUICIA_TITLE',
);
