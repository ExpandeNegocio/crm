<?php
// created: 2014-07-12 09:52:51
$dictionary["Expan_Franquicia"]["fields"]["expan_franquicia_expan_evento"] = array (
  'name' => 'expan_franquicia_expan_evento',
  'type' => 'link',
  'relationship' => 'expan_franquicia_expan_evento',
  'source' => 'non-db',
  'module' => 'Expan_Evento',
  'bean_name' => 'Expan_Evento',
  'vname' => 'LBL_EXPAN_FRANQUICIA_EXPAN_EVENTO_FROM_EXPAN_EVENTO_TITLE',
);
