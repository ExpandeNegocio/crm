<?php
$module_name = 'Expan_Solicitud';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '3',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_DETAILVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'title',
          1 => 'phone_work',
          2 => 'full_name',
        ),
        1 => 
        array (
          0 => 'phone_mobile',
          1 => 'phone_home',
          2 => '',
        ),
        2 => 
        array (
          0 => '',
          1 => '',
          2 => 'department',
        ),
        3 => 
        array (
          0 => 'email1',
          1 => '',
        ),
        4 => 
        array (
          0 => 'primary_address_street',
          1 => 'alt_address_street',
          2 => '',
        ),
        5 => 
        array (
          0 => 'description',
          1 => '',
        ),
      ),
      'lbl_detailview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'perfil_franquicia',
            'studio' => 'visible',
            'label' => 'LBL_PERFIL_FRANQUICIA',
          ),
          1 => 
          array (
            'name' => 'situacion_profesional',
            'studio' => 'visible',
            'label' => 'LBL_SITUACION_PROFESIONAL',
          ),
          2 => 
          array (
            'name' => 'perfil_profesional',
            'label' => 'LBL_PERFIL_PROFESIONAL',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'cuando_empezar',
            'studio' => 'visible',
            'label' => 'LBL_CUANDO_EMPEZAR',
          ),
          1 => 
          array (
            'name' => 'negocio_antes',
            'label' => 'LBL_NEGOCIO_ANTES',
          ),
          2 => '',
        ),
      ),
    ),
  ),
);
?>
