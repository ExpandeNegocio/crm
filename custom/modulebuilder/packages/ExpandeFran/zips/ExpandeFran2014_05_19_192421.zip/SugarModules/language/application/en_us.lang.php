<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/


$app_list_strings['moduleList']['Expan_Solicitud'] = 'Solicitud';
$app_list_strings['perfil_fran_list']['auto'] = 'autoempleo';
$app_list_strings['perfil_fran_list']['gestor'] = 'gestor';
$app_list_strings['perfil_fran_list']['inversor'] = 'inversor';
$app_list_strings['perfil_fran_list']['Corner'] = 'Corner';
$app_list_strings['situacion_profesional_list']['Cuentaajena'] = 'Cuenta ajena';
$app_list_strings['situacion_profesional_list']['Cuentapropia'] = 'Cuenta propia';
$app_list_strings['situacion_profesional_list']['Enbusqueda'] = 'En busqueda';
$app_list_strings['cuando_empezar_list']['inmediatamente'] = 'inmediatamente';
$app_list_strings['cuando_empezar_list']['en6meses'] = 'en 6 meses';
$app_list_strings['cuando_empezar_list']['en1anoomas'] = 'en 1 año o más';
$app_list_strings['cuando_empezar_list']['alargoplazo'] = 'a largo plazo';
$app_list_strings['capital_list']['20000'] = 'menos de 20.000€';
$app_list_strings['capital_list']['50000'] = '20.000 - 50 000 €';
$app_list_strings['capital_list']['90000'] = '50.000 - 90.000 €';
$app_list_strings['capital_list']['150000'] = '90.000 - 150.000';
$app_list_strings['capital_list']['mas150000'] = 'más de 150.000 €';
$app_list_strings['capital_list']['otros'] = 'otros';
$app_list_strings['lst_sectores']['1'] = 'Panaderías y Pastelería';
$app_list_strings['lst_sectores']['2'] = 'Supermercados';
$app_list_strings['lst_sectores']['3'] = 'Tienda de Congelados';
$app_list_strings['lst_sectores']['4'] = 'Tienda de Vinos y licores';
$app_list_strings['lst_sectores']['5'] = 'Charcutería y carnicería';
$app_list_strings['lst_sectores']['6'] = 'Tienda Delicatesen Proyecto';
$app_list_strings['lst_sectores']['7'] = 'Tienda Frutos secos y dulces';
$app_list_strings['lst_sectores']['8'] = 'Fruterias';
$app_list_strings['lst_sectores']['9'] = 'Bares de copas y cócteles';
$app_list_strings['lst_sectores']['10'] = 'Bares de tapas y Cervecerías';
$app_list_strings['lst_sectores']['11'] = 'Cafeterías';
$app_list_strings['lst_sectores']['12'] = 'Coffee shops, Panaderías -Pastelería';
$app_list_strings['lst_sectores']['13'] = 'Heladerías y pequeños locales';
$app_list_strings['lst_sectores']['14'] = 'Restaurantes Temáticos';
$app_list_strings['lst_sectores']['15'] = 'Restaurantes';
$app_list_strings['lst_sectores']['16'] = 'Establecimientos Fast-Food';
$app_list_strings['lst_sectores']['17'] = 'Cocinas y baño';
$app_list_strings['lst_sectores']['18'] = 'Decoración hogar';
$app_list_strings['lst_sectores']['19'] = 'Muebles hogar';
$app_list_strings['lst_sectores']['20'] = 'Textil hogar';
$app_list_strings['lst_sectores']['21'] = 'tiendas de descanso';
$app_list_strings['lst_sectores']['22'] = 'Calzado y complementos';
$app_list_strings['lst_sectores']['23'] = 'Moda Deportiva y Sport';
$app_list_strings['lst_sectores']['24'] = 'Moda hombre';
$app_list_strings['lst_sectores']['25'] = 'Moda Infantil y Juvenil';
$app_list_strings['lst_sectores']['26'] = 'Moda Íntima';
$app_list_strings['lst_sectores']['27'] = 'Moda mujer';
$app_list_strings['lst_sectores']['28'] = 'Moda Nupcial';
$app_list_strings['lst_sectores']['29'] = 'Moda Unisex';
$app_list_strings['lst_sectores']['30'] = 'Alquiler y venta de vehículos';
$app_list_strings['lst_sectores']['31'] = 'Lavado del automóvil';
$app_list_strings['lst_sectores']['32'] = 'Reparación y mantenimiento automóvil';
$app_list_strings['lst_sectores']['33'] = 'Venta y mantenimiento de motocicletas';
$app_list_strings['lst_sectores']['34'] = 'Joyería-Bisutería';
$app_list_strings['lst_sectores']['35'] = 'Jugueterías, Regalos y fiesta';
$app_list_strings['lst_sectores']['36'] = 'Librerías - papelería - material oficina';
$app_list_strings['lst_sectores']['37'] = 'Tienda Artículos usados';
$app_list_strings['lst_sectores']['38'] = 'Tienda de Cigarrillos Electrónicos';
$app_list_strings['lst_sectores']['39'] = 'Tienda de Flores';
$app_list_strings['lst_sectores']['40'] = 'Tienda de Iluminación, Bricolaje, ferretería';
$app_list_strings['lst_sectores']['41'] = 'Tienda de material deportivo y de ocio';
$app_list_strings['lst_sectores']['42'] = 'Tiendas de Fotografía';
$app_list_strings['lst_sectores']['43'] = 'Tiendas de Informática - consumibles y reciclaje';
$app_list_strings['lst_sectores']['44'] = 'Tiendas de Mascotas - Animales';
$app_list_strings['lst_sectores']['45'] = 'Tiendas de perfumería y cosmética';
$app_list_strings['lst_sectores']['46'] = 'Tiendas de Precio único';
$app_list_strings['lst_sectores']['47'] = 'Tiendas de telefonía accesorios y comunicaciones';
$app_list_strings['lst_sectores']['48'] = 'Tiendas Eróticas';
$app_list_strings['lst_sectores']['49'] = 'Vending 24h';
$app_list_strings['lst_sectores']['50'] = 'Administracion de fincas';
$app_list_strings['lst_sectores']['51'] = 'Agencias Inmobiliarias';
$app_list_strings['lst_sectores']['52'] = 'Servicios de mantenimiento, reformas y construccion';
$app_list_strings['lst_sectores']['53'] = 'Academias de idiomas';
$app_list_strings['lst_sectores']['54'] = 'Actividades extraescolares y apoyo escolar';
$app_list_strings['lst_sectores']['55'] = 'Autoescuelas';
$app_list_strings['lst_sectores']['56'] = 'Guarderías y escuelas infantiles';
$app_list_strings['lst_sectores']['57'] = 'Servicios de Formación especializada';
$app_list_strings['lst_sectores']['58'] = 'Servicios de Formación profesional';
$app_list_strings['lst_sectores']['59'] = 'Actividades de ocio y tiempo libre';
$app_list_strings['lst_sectores']['60'] = 'Centros de Ocio';
$app_list_strings['lst_sectores']['61'] = 'parques infantiles';
$app_list_strings['lst_sectores']['62'] = 'Videoclubs y video cajeros';
$app_list_strings['lst_sectores']['63'] = 'gimnasios-spa-masajes';
$app_list_strings['lst_sectores']['64'] = 'Herboristerías ‐ nutrición ­ dietética';
$app_list_strings['lst_sectores']['65'] = 'Ópticas';
$app_list_strings['lst_sectores']['66'] = 'Parafarmacia';
$app_list_strings['lst_sectores']['67'] = 'Peluquerías y centros de estética';
$app_list_strings['lst_sectores']['68'] = 'Servicios médicos y dentales';
$app_list_strings['lst_sectores']['69'] = 'Agencias de empleo';
$app_list_strings['lst_sectores']['70'] = 'Agencias de Viajes';
$app_list_strings['lst_sectores']['71'] = 'Agencias Matrimoniales y sociales';
$app_list_strings['lst_sectores']['72'] = 'Compra venta oro y otros metales.';
$app_list_strings['lst_sectores']['73'] = 'Mantenimiento informático';
$app_list_strings['lst_sectores']['74'] = 'Organización de bodas y eventos sociales';
$app_list_strings['lst_sectores']['75'] = 'Servicios asistenciales a las personas';
$app_list_strings['lst_sectores']['76'] = 'Servicios Financieros y aseguradores';
$app_list_strings['lst_sectores']['77'] = 'Servicios veterinarios';
$app_list_strings['lst_sectores']['78'] = 'Sistemas de alarma y seguridad';
$app_list_strings['lst_sectores']['79'] = 'Tintorerias y limpieza';
$app_list_strings['lst_sectores']['80'] = 'Atención al cliente, call centers';
$app_list_strings['lst_sectores']['81'] = 'Comercialización, distribución y Venta';
$app_list_strings['lst_sectores']['82'] = 'Comunicación, Internet, Marketing y Publicidad';
$app_list_strings['lst_sectores']['83'] = 'Eventos, Regalos de empresa y relaciones públicas';
$app_list_strings['lst_sectores']['84'] = 'limpieza, seguridad y mantenimiento profesional e industrial';
$app_list_strings['lst_sectores']['85'] = 'Consultoria';
$app_list_strings['lst_sectores']['86'] = 'Mantenimiento informático';
$app_list_strings['lst_sectores']['87'] = 'Rotulación e impresión';
$app_list_strings['lst_sectores']['88'] = 'Transporte y Mensajería';
$app_list_strings['franquicia_list']['1'] = '2MOBILE';
$app_list_strings['franquicia_list']['2'] = 'AEROMEDIA';
$app_list_strings['franquicia_list']['3'] = 'ANTONIA BUTRÓN';
$app_list_strings['franquicia_list']['4'] = 'CANAL OCIO';
$app_list_strings['franquicia_list']['5'] = 'CATIVOS';
$app_list_strings['franquicia_list']['6'] = 'CHISPASAT';
$app_list_strings['franquicia_list']['7'] = 'CORPORANZA';
$app_list_strings['franquicia_list']['8'] = 'EASY';
$app_list_strings['franquicia_list']['9'] = 'EDUCO';
$app_list_strings['franquicia_list']['10'] = 'EH VOILA';
$app_list_strings['franquicia_list']['11'] = 'ESTVDIO';
$app_list_strings['franquicia_list']['12'] = 'FOOTPLUS';
$app_list_strings['franquicia_list']['13'] = 'HELLS';
$app_list_strings['franquicia_list']['14'] = 'HTTV Media';
$app_list_strings['franquicia_list']['15'] = 'KNACK';
$app_list_strings['franquicia_list']['16'] = 'LEDS HOME';
$app_list_strings['franquicia_list']['17'] = 'MINICALL';
$app_list_strings['franquicia_list']['18'] = 'NyN';
$app_list_strings['franquicia_list']['19'] = 'ROSCO KING';
$app_list_strings['franquicia_list']['20'] = 'VUELTA Y VUELTA';
$app_list_strings['franquicia_list']['21'] = 'WEEKEND';
$app_list_strings['franquicia_list']['1000'] = 'ENVIAR SERVICIOS';
$app_list_strings['franquicia_list']['1001'] = 'OTRAS CADENAS';
$app_list_strings['estado_sol_list']['1'] = '1-No Atendido';
$app_list_strings['estado_sol_list']['2'] = '2-Programada acción de seguimiento';
$app_list_strings['estado_sol_list']['3'] = '2-Programada acción de seguimiento';
$app_list_strings['estado_sol_list']['4'] = '4-No localizado';
$app_list_strings['estado_sol_list']['5'] = '5-Datos erróneos';
$app_list_strings['estado_sol_list']['6'] = '6-Descartado por nosotros';
$app_list_strings['estado_sol_list']['7'] = '7-Descartado por el candidato';
$app_list_strings['estado_sol_list']['8'] = '8-Zona de no interés';
$app_list_strings['estado_sol_list']['9'] = '9-Colaboración con franquiciador';
$app_list_strings['estado_sol_list']['10'] = '10-Franquiciado';
$app_list_strings['zonas_list']['10'] = 'Resto';
$app_list_strings['actuacion_inmediata_list']['1'] = 'Ejecución de documento';
$app_list_strings['actuacion_inmediata_list']['2'] = 'Pendiente protocolo Intermediación.';
$app_list_strings['actuacion_inmediata_list']['3'] = 'Gestión externa (gestión paralela al seguimiento de la propia candidatura)';
$app_list_strings['actuacion_inmediata_list']['4'] = 'Volver a enviar documentación';
$app_list_strings['perfil_plurifranquiciado_list']['1'] = 'Perfil Plurifranquiciado';
$app_list_strings['perfil_plurifranquiciado_list']['2'] = 'Capacidad Inversión Alta';
$app_list_strings['rating_list']['1'] = 'A+';
$app_list_strings['rating_list']['2'] = 'A';
$app_list_strings['rating_list']['3'] = 'B';
$app_list_strings['rating_list']['4'] = 'C';
