<?php
// created: 2014-05-19 19:24:16
$dictionary["Expan_Solicitud"]["fields"]["expan_solicitud_calls"] = array (
  'name' => 'expan_solicitud_calls',
  'type' => 'link',
  'relationship' => 'expan_solicitud_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'side' => 'right',
  'vname' => 'LBL_EXPAN_SOLICITUD_CALLS_FROM_CALLS_TITLE',
);
