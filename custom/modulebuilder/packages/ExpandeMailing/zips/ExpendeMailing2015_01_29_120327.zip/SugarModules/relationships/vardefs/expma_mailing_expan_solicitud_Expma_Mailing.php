<?php
// created: 2015-01-29 12:03:27
$dictionary["Expma_Mailing"]["fields"]["expma_mailing_expan_solicitud"] = array (
  'name' => 'expma_mailing_expan_solicitud',
  'type' => 'link',
  'relationship' => 'expma_mailing_expan_solicitud',
  'source' => 'non-db',
  'module' => 'Expan_Solicitud',
  'bean_name' => 'Expan_Solicitud',
  'side' => 'right',
  'vname' => 'LBL_EXPMA_MAILING_EXPAN_SOLICITUD_FROM_EXPAN_SOLICITUD_TITLE',
);
