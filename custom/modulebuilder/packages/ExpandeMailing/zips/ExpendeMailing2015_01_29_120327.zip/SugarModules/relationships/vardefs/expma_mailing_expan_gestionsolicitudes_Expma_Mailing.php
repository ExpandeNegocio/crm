<?php
// created: 2015-01-29 10:43:56
$dictionary["Expma_Mailing"]["fields"]["expma_mailing_expan_gestionsolicitudes"] = array (
  'name' => 'expma_mailing_expan_gestionsolicitudes',
  'type' => 'link',
  'relationship' => 'expma_mailing_expan_gestionsolicitudes',
  'source' => 'non-db',
  'module' => 'Expan_GestionSolicitudes',
  'bean_name' => 'Expan_GestionSolicitudes',
  'side' => 'right',
  'vname' => 'LBL_EXPMA_MAILING_EXPAN_GESTIONSOLICITUDES_FROM_EXPAN_GESTIONSOLICITUDES_TITLE',
);
