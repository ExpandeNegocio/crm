<?php
 // created: 2015-01-31 10:20:16
$layout_defs["Expma_Mailing"]["subpanel_setup"]['expma_mailing_expan_solicitud'] = array (
  'order' => 100,
  'module' => 'Expan_Solicitud',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_EXPMA_MAILING_EXPAN_SOLICITUD_FROM_EXPAN_SOLICITUD_TITLE',
  'get_subpanel_data' => 'expma_mailing_expan_solicitud',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
